import sys,os

infile=sys.argv[1]
with open(infile) as f:
	pdbids=f.read().splitlines()
for ids in pdbids:
	string="cp ../allpdbs/"+ids+".pdb ."
	os.system(string)